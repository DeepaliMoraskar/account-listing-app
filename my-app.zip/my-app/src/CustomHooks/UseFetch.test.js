/**
 * @jest-environment node 
 */
import { renderHook, act } from "@testing-library/react";
import axios from "axios";
import useFetch from "./UseFetch.js";
import { JSDOM } from 'jsdom';

const { window } = new JSDOM('<!doctype html><html><body></body></html>');

global.window = window;
global.document = window.document;

jest.mock("axios");

describe("useFetch", () => {
  test("fetches data successfully", async () => {
    const responseData = [
      { id: 1, name: "Account 1" },
      { id: 2, name: "Account 2" },
    ];
    jest.spyOn(axios, "get").mockResolvedValueOnce({ data: responseData });

    const { result } = renderHook(() =>
      useFetch("https://recruitmentdb-508d.restdb.io/rest/accounts")
    );

    expect(result.current[1]).toBe(true); // Check the loading state

    await act(async () => {
        await new Promise((resolve) => setTimeout(resolve, 0)); // Wait for the next tick
    });

    expect(result.current[0]).toEqual(responseData); // Check the data state
    expect(result.current[1]).toBe(false); // Check the loading state
    expect(result.current[2]).toBe(""); // Check the error state
  });

  test("handles error when fetching data", async () => {
    const errorMessage = "Error fetching data";
    axios.get.mockRejectedValueOnce(new Error(errorMessage));

    const { result } = renderHook(() =>
      useFetch("https://recruitmentdb-508d.restdb.io/rest/accounts")
    );

    expect(result.current[1]).toBe(true);
    expect(result.current[2]).toBe("");

    await act(async () => {
        await new Promise((resolve) => setTimeout(resolve, 0)); // Wait for the next tick
    });

    expect(result.current[0]).toEqual([]);
    expect(result.current[1]).toBe(false);
    expect(result.current[2]).toBe(errorMessage);
  });

  test("ensures data state is always an array", async () => {
    axios.get.mockResolvedValueOnce({ data: null });

    const { result } = renderHook(() =>
      useFetch("hhttps://recruitmentdb-508d.restdb.io/rest/accounts")
    );

    expect(result.current[1]).toBe(true);
    expect(result.current[2]).toBe("");

    await act(async () => {
        await new Promise((resolve) => setTimeout(resolve, 0)); // Wait for the next tick
    });

    expect(result.current[0]).toEqual([]);
    expect(result.current[1]).toBe(false);
    expect(result.current[2]).toBe("");
  });
});
