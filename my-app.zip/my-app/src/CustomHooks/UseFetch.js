import { useEffect, useState } from "react";
import axios from "axios";

const useFetch = (url) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const config = {
          headers: {
            "x-apikey": "5d9f48133cbe87164d4bb12c"
          }
        };
        const response = await axios.get(url, config);
        setData(response.data || []); // Ensure data is always an array
        setLoading(false);
        setError("");
      } catch (error) {
        setError('Error fetching data');
        setLoading(false);
      }
    };
    
    fetchData();
  }, [url]);

  
  return [data, loading, error];
};

export default useFetch;
