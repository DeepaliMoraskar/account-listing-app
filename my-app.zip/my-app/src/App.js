import React from 'react';
import './App.css';
import AccountTable from './Components/AccountTable';
import useFetch from "./CustomHooks/UseFetch";

const accountsUrl = `https://recruitmentdb-508d.restdb.io/rest/accounts`;
const accountTypeUrl = `https://recruitmentdb-508d.restdb.io/rest/accounttypes`;

function App() {

  const [data, loading, error] = useFetch(accountsUrl);
  const [list] = useFetch(accountTypeUrl);

  return (
    <div className="App">
      <AccountTable data={data} list={list} loading={loading} error={error}/>
    </div>
  );
}

export default App;
