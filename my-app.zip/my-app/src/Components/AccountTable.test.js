import React from 'react';
import { render, screen, within } from '@testing-library/react';
import '@testing-library/jest-dom'
import AccountTable from './AccountTable';

const mockAccounts = [
  { name: 'Account 1', profitLoss: 1000, accountType: 1 },
  { name: 'Account 2', profitLoss: -500, accountType: 2 },
  { name: 'Account 3', profitLoss: 600, accountType: 5 },
  { name: 'Account 4', profitLoss: 700, accountType: 5 }];
const mockAccountTypes = [
  { _id: "5d9dea6c9151612800008618",
  id: 2,
  title: "Spread bet account" },
  { _id: "5d9dea6c915161280000822",
  id: 1,
  title: "CFD account" },
  { _id: "5d9dea6c915161280000822",
  id: 5,
  title: "Forex account" }
];

describe('AccountTable', () => {

  it('should render loading text when data is loading', () => {
       render(<AccountTable data={[]} list={[]} loading={true} error={''} />);
       expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('should render error message when there is an error fetching data', () => {
    render(<AccountTable data={[]} list={[]} loading={false} error={'Error fetching data'} />);
    expect(screen.getByText('Error fetching data')).toBeInTheDocument();
  });


  it('should render account table with correct data', () => {
    render(<AccountTable data={mockAccounts} list={mockAccountTypes} loading={false} error={''} />);
      mockAccounts.map((account) => {
          expect(screen.getByText(account.name)).toBeInTheDocument();
          expect(screen.getByText(account.profitLoss.toString())).toBeInTheDocument();
      });

      const tableContainer = screen.getByRole('table');
      mockAccountTypes.forEach((account) => {
        const accountTitle = within(tableContainer).getAllByText(account.title);
        expect(accountTitle.length).toBeGreaterThan(0);
      });
    });
});
